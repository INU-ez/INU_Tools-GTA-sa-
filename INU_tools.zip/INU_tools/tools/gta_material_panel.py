# INU_tools.tools.gta_material_panel
#
# Condensed "GTA Material" panel for the material Properties tab. It
# surfaces the most common GTA SA modding knobs in one place:
#   • preset dropdown (built-ins + user-saved presets from INU_Preset)
#   • vehicle color slot (Primary/Secondary/Headlight/…)
#   • one-click "apply preset" + Save / Delete
#
# Underlying state is still stored in `mat.inu.*` custom properties so
# it round-trips through the existing DFF writer — this file only adds
# UI + orchestration.

from __future__ import annotations

import bpy

from ..data import material_presets as _mp


# Built-in presets — shipped with the addon, always available.
PRESETS = (
    ('GENERIC',  "Generic",       "Plain textured material, no effects"),
    ('VEHICLE',  "Vehicle Body",  "xvehicleenv128 + vehiclespecdot64 + reflection blend"),
    ('VEHICLE_GLASS', "Vehicle Glass", "Transparent glass with env map"),
    ('PED',      "Ped / Skinned", "Plain skinned material, alpha from texture"),
    ('ENV',      "Env Mapped",    "Environment map only, no specular/reflection"),
    ('DUAL',     "Dual Texture",  "Blend with a second texture (decal/detail)"),
    ('SPECULAR', "Specular",      "Plain specular highlight from a mask texture"),
)


def _reset_effects(inu):
    """Clear every optional effect flag so presets apply from a clean base."""
    for flag in ('export_env_map', 'export_bump_map', 'export_reflection',
                 'export_specular', 'export_dual_tex', 'export_animation',
                 'uv_anim_write'):
        if hasattr(inu, flag):
            try:
                setattr(inu, flag, False)
            except Exception:
                pass


def apply_preset(mat, preset: str):
    """Apply one of the `PRESETS` identifiers to `mat.inu.*`.

    Returns a short human-readable description of what was applied.
    """
    inu = getattr(mat, 'inu', None)
    if not inu:
        return "no inu props on material"

    _reset_effects(inu)

    if preset == 'GENERIC':
        return "Generic — effects cleared"

    if preset == 'VEHICLE':
        inu.export_env_map = True
        inu.env_map_tex = 'xvehicleenv128'
        inu.env_map_coef = 0.2
        inu.env_map_fb_alpha = False
        inu.export_specular = True
        inu.specular_level = 1.0
        inu.specular_texture = 'vehiclespecdot64'
        inu.export_reflection = True
        inu.reflection_scale_x = 1.0
        inu.reflection_scale_y = 1.0
        inu.reflection_intensity = 0.05
        return "Vehicle Body — env + specular + reflection"

    if preset == 'VEHICLE_GLASS':
        inu.export_env_map = True
        inu.env_map_tex = 'xvehicleenv128'
        inu.env_map_coef = 0.4
        inu.env_map_fb_alpha = True
        return "Vehicle Glass — env map with FB alpha"

    if preset == 'PED':
        return "Ped — plain skinned material"

    if preset == 'ENV':
        inu.export_env_map = True
        inu.env_map_tex = 'xenvmap'
        inu.env_map_coef = 0.5
        return "Env Mapped"

    if preset == 'DUAL':
        inu.export_dual_tex = True
        inu.dual_tex_src_blend = '5'   # SRCALPHA
        inu.dual_tex_dst_blend = '6'   # INVSRCALPHA
        return "Dual Texture — standard alpha blend"

    if preset == 'SPECULAR':
        inu.export_specular = True
        inu.specular_level = 1.0
        return "Specular — level 1.0"

    return f"unknown preset {preset}"


# ── Dynamic preset dropdown ─────────────────────────────────────────

# Cache invalidated by Save/Delete operators. Items must be kept alive
# (returning a fresh list every call triggers Blender's Python GC on
# the strings and breaks the dropdown — see bpy.props docs).
_items_cache: list = []


def invalidate_cache():
    global _items_cache
    _items_cache = []


def preset_items(self, context):
    """Enum items callback: built-ins + user presets from INU_Preset."""
    items = [(p_id, p_name, p_desc) for p_id, p_name, p_desc in PRESETS]
    user = _mp.list_presets()
    for name in user:
        # 'USER:<name>' encoded id, actual name shown in the label
        items.append((f'USER:{name}', name, f'Пользовательский пресет: {name}'))

    global _items_cache
    _items_cache = items
    return _items_cache


# ──────────────────────────── operators ──────────────────────────────

class GTATOOLS_OT_material_preset(bpy.types.Operator):
    """Записать выбранный GTA Material пресет в свойства mat.inu.*"""
    bl_idname = "gtatools.material_preset"
    bl_label = "Apply Material Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset: bpy.props.StringProperty(default='VEHICLE')

    @classmethod
    def poll(cls, context):
        return context.material is not None

    def execute(self, context):
        mat = context.material
        inu = getattr(mat, 'inu', None)
        if not inu:
            self.report({'ERROR'}, "no inu props")
            return {'CANCELLED'}

        if self.preset.startswith('USER:'):
            user_name = self.preset[5:]
            _reset_effects(inu)
            data = _mp.load_preset(user_name)
            if not data:
                self.report({'ERROR'}, f"preset not found: {user_name}")
                return {'CANCELLED'}
            count = _mp.apply_to_inu(inu, data)
            self.report({'INFO'}, f"{user_name}: applied {count} fields")
        else:
            msg = apply_preset(mat, self.preset)
            self.report({'INFO'}, msg)

        return {'FINISHED'}


class GTATOOLS_OT_material_preset_save(bpy.types.Operator):
    """Сохранить текущие настройки материала как новый пресет"""
    bl_idname = "gtatools.material_preset_save"
    bl_label = "Сохранить пресет"
    bl_options = {'REGISTER'}

    preset_name: bpy.props.StringProperty(
        name="Имя",
        description="Имя пресета (буквы, цифры, дефис, подчёркивание, пробел)",
        default="",
    )
    description: bpy.props.StringProperty(
        name="Описание",
        description="Короткое описание (необязательно)",
        default="",
    )

    @classmethod
    def poll(cls, context):
        return context.material is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, 'preset_name')
        col.prop(self, 'description')

    def execute(self, context):
        mat = context.material
        inu = getattr(mat, 'inu', None)
        if not inu:
            self.report({'ERROR'}, "no inu props")
            return {'CANCELLED'}
        name = (self.preset_name or '').strip()
        if not name:
            self.report({'ERROR'}, "имя обязательно")
            return {'CANCELLED'}
        data = _mp.capture_from_inu(inu)
        if not _mp.save_preset(name, data, self.description):
            self.report({'ERROR'}, "ошибка сохранения")
            return {'CANCELLED'}
        invalidate_cache()
        # Select the newly saved preset
        try:
            context.scene.gtatools_material_preset = f'USER:{name}'
        except Exception:
            pass
        self.report({'INFO'}, f"сохранён: {name}")
        return {'FINISHED'}


class GTATOOLS_OT_material_preset_delete(bpy.types.Operator):
    """Удалить пользовательский пресет (встроенные удалить нельзя)"""
    bl_idname = "gtatools.material_preset_delete"
    bl_label = "Удалить пресет"
    bl_options = {'REGISTER'}

    preset_name: bpy.props.StringProperty(default="")

    def execute(self, context):
        if not self.preset_name:
            self.report({'ERROR'}, "нет выбранного пресета")
            return {'CANCELLED'}
        if not _mp.delete_preset(self.preset_name):
            self.report({'ERROR'}, "не удалось удалить")
            return {'CANCELLED'}
        invalidate_cache()
        # Reset dropdown to a built-in
        try:
            context.scene.gtatools_material_preset = 'GENERIC'
        except Exception:
            pass
        self.report({'INFO'}, f"удалён: {self.preset_name}")
        return {'FINISHED'}


# ──────────────────────────── panel ──────────────────────────────────

class GTATOOLS_PT_gta_material_panel(bpy.types.Panel):
    bl_label = "GTA Material"
    bl_idname = "GTATOOLS_PT_gta_material_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'material'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.material is not None

    def draw(self, context):
        layout = self.layout
        mat = context.material
        inu = getattr(mat, 'inu', None)
        if not inu:
            layout.label(text="No inu properties on material", icon='ERROR')
            return

        scene = context.scene
        current = getattr(scene, 'gtatools_material_preset', 'GENERIC') or 'GENERIC'
        is_user = current.startswith('USER:')

        # Preset dropdown + Apply
        box = layout.box()
        box.label(text="Preset", icon='PRESET')
        row = box.row(align=True)
        row.prop(scene, 'gtatools_material_preset', text="")
        op = row.operator("gtatools.material_preset", text="", icon='CHECKMARK')
        op.preset = current

        # Save always available; Delete only when a user preset is active
        row = box.row(align=True)
        row.operator("gtatools.material_preset_save",
                     text="Сохранить как…", icon='ADD')
        del_row = row.row(align=True)
        del_row.enabled = is_user
        op_del = del_row.operator("gtatools.material_preset_delete",
                                  text="Удалить", icon='REMOVE')
        op_del.preset_name = current[5:] if is_user else ''

        # Vehicle color slot (carcols.dat magic)
        box = layout.box()
        box.label(text="Vehicle Color", icon='COLOR')
        box.prop(inu, "vehicle_color_slot", text="")

        # Quick toggles summary
        box = layout.box()
        box.label(text="Active Effects", icon='MODIFIER')
        col = box.column(align=True)
        for attr, label in (
            ('export_env_map',    "Env Map"),
            ('export_bump_map',   "Bump Map"),
            ('export_specular',   "Specular"),
            ('export_reflection', "Reflection"),
            ('export_dual_tex',   "Dual Texture"),
            ('uv_anim_write',     "UV Animation"),
        ):
            if hasattr(inu, attr):
                col.prop(inu, attr, text=label)


classes = (
    GTATOOLS_OT_material_preset,
    GTATOOLS_OT_material_preset_save,
    GTATOOLS_OT_material_preset_delete,
    GTATOOLS_PT_gta_material_panel,
)
